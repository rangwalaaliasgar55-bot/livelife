import { db } from "@/db";
import { gameSaves } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { applyAction } from "@/lib/sim/actions";
import { createGame } from "@/lib/sim/create";
import { computeNetWorth } from "@/lib/sim/finance";
import type { GameState, NewGameInput, PlayerAction } from "@/lib/sim/types";
import { monthName, uid } from "@/lib/sim/util";

function summaryLine(state: GameState): string {
  const job = state.player.career.job?.title ?? (state.player.ownedCompanyIds.length ? "Founder" : "Private citizen");
  const city = state.world.cities.find((c) => c.id === state.player.cityId)?.name ?? "";
  return `${job} · ${city}`;
}

function rowFrom(state: GameState, id: string, name: string, createdAt?: Date) {
  return {
    id,
    name,
    mode: state.mode,
    playerName: state.player.name,
    year: state.time.year,
    month: state.time.month,
    netWorth: computeNetWorth(state),
    age: state.player.age,
    country: state.world.countries.find((c) => c.id === state.player.countryId)?.name ?? "",
    summary: summaryLine(state),
    state: state as unknown as Record<string, unknown>,
    updatedAt: new Date(),
    ...(createdAt ? { createdAt } : {}),
  };
}

export async function listSaves() {
  const rows = await db.select().from(gameSaves).orderBy(desc(gameSaves.updatedAt));
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    mode: r.mode,
    playerName: r.playerName,
    year: r.year,
    month: r.month,
    monthName: monthName(r.month),
    netWorth: r.netWorth,
    age: r.age,
    country: r.country,
    summary: r.summary,
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
  }));
}

export async function createSave(input: NewGameInput, slotName?: string) {
  const state = createGame(input);
  const id = uid("life");
  const name = slotName || `${input.name} · ${input.mode}`;
  await db.insert(gameSaves).values(rowFrom(state, id, name));
  return { id, state };
}

export async function loadSave(id: string): Promise<GameState | null> {
  const rows = await db.select().from(gameSaves).where(eq(gameSaves.id, id)).limit(1);
  const row = rows[0];
  if (!row) return null;
  return row.state as GameState;
}

export async function persistState(id: string, state: GameState) {
  state.lastSave = new Date().toISOString();
  await db
    .update(gameSaves)
    .set({
      playerName: state.player.name,
      year: state.time.year,
      month: state.time.month,
      netWorth: computeNetWorth(state),
      age: state.player.age,
      country: state.world.countries.find((c) => c.id === state.player.countryId)?.name ?? "",
      summary: summaryLine(state),
      state: state as unknown as Record<string, unknown>,
      updatedAt: new Date(),
    })
    .where(eq(gameSaves.id, id));
}

export async function actOnSave(id: string, action: PlayerAction) {
  const state = await loadSave(id);
  if (!state) return { error: "Save not found", status: 404 as const };
  const result = applyAction(state, action);
  await persistState(id, result.state);
  return { state: result.state, log: result.log, error: result.error };
}

export async function deleteSave(id: string) {
  await db.delete(gameSaves).where(eq(gameSaves.id, id));
}

export async function duplicateSave(id: string) {
  const state = await loadSave(id);
  if (!state) return null;
  const nid = uid("life");
  await db.insert(gameSaves).values(rowFrom(structuredClone(state), nid, `${state.player.name} (copy)`));
  return nid;
}
