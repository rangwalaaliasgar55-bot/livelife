import { BILL_TOPICS, INDUSTRIES, SKILLS, TRACKS, industryMeta } from "./catalog";
import { history, news, note, rng, tickMonths, timeline, unlock } from "./engine";
import { computeNetWorth, credit, liquidCash, monthlyLoanPayment, spend } from "./finance";
import type {
  EducationTrack,
  FoundPayload,
  GameState,
  Industry,
  ListedCompany,
  PlayerAction,
  PolicyVector,
  SkillId,
} from "./types";
import { chance, clamp, formatDate, formatINR, normal, pick, round, uid } from "./util";

export function applyAction(state: GameState, action: PlayerAction): { state: GameState; log: string[]; error?: string } {
  const log: string[] = [];
  try {
    switch (action.type) {
      case "tick":
        tickMonths(state, action.months ?? 1);
        log.push(`Lived ${action.months ?? 1} month(s).`);
        break;
      case "study":
        startStudy(state, action.track, action.level, log);
        break;
      case "dropStudy":
        if (state.player.currentStudy) {
          state.player.currentStudy.inProgress = false;
          log.push(`Left ${state.player.currentStudy.name}.`);
          state.player.currentStudy = null;
        }
        break;
      case "selfLearn":
      case "practice":
        trainSkill(state, action.skill, 1.2, 0, log);
        break;
      case "course":
        trainSkill(state, action.skill, 4, 18000, log);
        break;
      case "applyJob":
        applyJob(state, action.jobId, log);
        break;
      case "quitJob":
        quitJob(state, log);
        break;
      case "freelance":
        state.player.career.freelance = { active: true, rate: 400 + state.player.skills.programming * 12, hours: action.hours, industry: action.industry };
        log.push(`Freelance ${action.industry}, ${action.hours}h/week.`);
        break;
      case "stopFreelance":
        state.player.career.freelance.active = false;
        log.push("Stopped freelancing.");
        break;
      case "openAccount":
        openAccount(state, action.bankId, action.kind, log);
        break;
      case "deposit":
        deposit(state, action.accountId, action.amount, log);
        break;
      case "withdraw":
        withdraw(state, action.accountId, action.amount, log);
        break;
      case "transfer":
        transfer(state, action.fromId, action.toId, action.amount, log);
        break;
      case "applyLoan":
        applyLoan(state, action.kind, action.amount, action.termMonths, log);
        break;
      case "repayLoan":
        repayLoan(state, action.loanId, action.amount, log);
        break;
      case "buyStock":
        tradeStock(state, action.ticker, action.shares, "buy", log);
        break;
      case "sellStock":
        tradeStock(state, action.ticker, action.shares, "sell", log);
        break;
      case "buyBond":
        buyBond(state, action.bondId, action.qty, log);
        break;
      case "sellBond":
        sellBond(state, action.bondId, action.qty, log);
        break;
      case "buyFund":
        buyFund(state, action.fundId, action.amount, log);
        break;
      case "sellFund":
        sellFund(state, action.fundId, action.units, log);
        break;
      case "buyProperty":
        buyProperty(state, action.listingId, action.mortgage, log);
        break;
      case "sellProperty":
        sellProperty(state, action.propertyId, log);
        break;
      case "renovate":
        renovate(state, action.propertyId, action.spend, log);
        break;
      case "setRent":
        setRent(state, action.propertyId, action.occupancyBias, log);
        break;
      case "develop":
        develop(state, action.propertyId, log);
        break;
      case "advanceBuild":
        break;
      case "foundCompany":
        foundCompany(state, action.payload, log);
        break;
      case "manageCompany":
        manageCompany(state, action.companyId, action.patch, log);
        break;
      case "raiseFunding":
        raiseFunding(state, action.companyId, action.source, action.amount, log);
        break;
      case "ipo":
        ipo(state, action.companyId, log);
        break;
      case "buyCompany":
        buyCompany(state, action.companyId, log);
        break;
      case "sellShares":
        sellShares(state, action.companyId, action.pct, log);
        break;
      case "appointCeo":
        appointCeo(state, action.companyId, action.self, log);
        break;
      case "applyGrant":
        applyGrant(state, action.grantId, action.companyId, log);
        break;
      case "pursueOpportunity":
        pursueOpportunity(state, action.opportunityId, log);
        break;
      case "travel":
        travel(state, action.countryId, action.cityId, action.intent, log);
        break;
      case "applyResidency":
        applyResidency(state, log);
        break;
      case "applyCitizenship":
        applyCitizenship(state, log);
        break;
      case "joinParty":
        joinParty(state, action.partyId, log);
        break;
      case "createParty":
        createParty(state, action.name, action.platform, log);
        break;
      case "campaign":
        campaign(state, action.spend, log);
        break;
      case "runForOffice":
        runForOffice(state, action.office, log);
        break;
      case "setPolicy":
        setPolicy(state, action.policy, log);
        break;
      case "proposeBill":
        proposeBill(state, action.topic, action.magnitude, log);
        break;
      case "appointMinister":
        log.push(`Appointed ${action.name} to cabinet.`);
        history(state, "politics", `Appointed minister ${action.name}`);
        break;
      case "conVote":
        conVote(state, action.resolutionId, action.vote, log);
        break;
      case "conPropose":
        conPropose(state, action.title, log);
        break;
      case "socialPost":
        socialPost(state, action.platform, action.topic, action.spend, log);
        break;
      case "foundMedia":
        foundMedia(state, action.kind, action.name, log);
        break;
      case "crimeAct":
        crimeAct(state, action.kind, action.intensity, log);
        break;
      case "foundOrg":
        foundOrg(state, action.kind, action.name, action.doctrine, log);
        break;
      case "orgAct":
        orgAct(state, action.orgId, action.act, log);
        break;
      case "gamble":
        gamble(state, action.game, action.stake, action.extra ?? {}, log);
        break;
      case "foundCasino":
        foundCasino(state, action.name, action.cityId, log);
        break;
      case "foundBank":
        foundBank(state, action.name, log);
        break;
      case "foundInsurer":
        foundInsurer(state, action.name, log);
        break;
      case "buyInsurance":
        buyInsurance(state, action.kind, log);
        break;
      case "haveChild":
        haveChild(state, log);
        break;
      case "setHeir":
        state.player.family.willHeirId = action.memberId;
        log.push("Heir updated.");
        break;
      case "continueAsHeir":
        continueAsHeir(state, log);
        break;
      case "interview":
        interview(state, action.tone, log);
        break;
      case "resolve":
        resolveDecision(state, action.decisionId, action.optionId, log);
        break;
      case "rest":
        state.player.energy = clamp(state.player.energy + 18, 0, 100);
        state.player.stress = clamp(state.player.stress - 10, 0, 100);
        log.push("You rested.");
        break;
      case "workout":
        state.player.health = clamp(state.player.health + 2, 0, 100);
        state.player.energy = clamp(state.player.energy - 6, 0, 100);
        log.push("Training complete.");
        break;
      case "network":
        network(state, log);
        break;
      case "createFund":
        createFund(state, action.name, action.kind, log);
        break;
      case "fxConvert":
        log.push("Balances are stored in base rupees; FX is marked on foreign accounts.");
        break;
      default:
        log.push("Unknown action");
    }
  } catch (e) {
    return { state, log, error: e instanceof Error ? e.message : "Action failed" };
  }
  return { state, log };
}

function date(state: GameState) {
  return formatDate(state.time.year, state.time.month);
}

function startStudy(state: GameState, track: EducationTrack, level: GameState["player"]["education"][number]["level"], log: string[]) {
  const p = state.player;
  if (p.currentStudy) {
    log.push("Already studying.");
    return;
  }
  const t = TRACKS.find((x) => x.id === track) ?? TRACKS[0]!;
  const tuition = level === "university" ? 220000 : level === "college" ? 90000 : level === "course" ? 18000 : 40000;
  const rec = {
    id: uid("edu"),
    level,
    name: `${t.name} ${level}`,
    track,
    institution: level === "university" ? "Capital University" : level === "course" ? "Open Network" : "Civic College",
    countryId: p.countryId,
    startYear: state.time.year,
    endYear: null,
    tuition,
    scholarship: p.educationLevel >= 3 && p.traits.discipline > 60 ? 40000 : 0,
    loan: 0,
    gpa: 3.0,
    completed: false,
    inProgress: true,
  };
  p.education.push(rec);
  p.currentStudy = rec;
  timeline(state, `Started ${rec.name}.`, "education");
  log.push(`Enrolled in ${rec.name}. Tuition ${formatINR(tuition)}/yr.`);
}

function trainSkill(state: GameState, skill: SkillId, amt: number, cost: number, log: string[]) {
  if (cost && !spend(state.player, cost, `Course · ${skill}`, "edu", date(state))) {
    log.push("Cannot afford the course.");
    return;
  }
  const cur = state.player.skills[skill] ?? 0;
  state.player.skills[skill] = clamp(cur + amt * (1.1 - cur / 140), 0, 100);
  log.push(`${SKILLS.find((s) => s.id === skill)?.name ?? skill} → ${state.player.skills[skill]!.toFixed(0)}`);
}

function applyJob(state: GameState, jobId: string, log: string[]) {
  const job = state.world.jobs.find((j) => j.id === jobId);
  if (!job) {
    log.push("Job listing gone.");
    return;
  }
  const p = state.player;
  if (p.age < 16) {
    log.push("Too young.");
    return;
  }
  const eduOk = p.educationLevel >= job.educationMin;
  const expOk = p.career.experience + 0.4 >= job.experienceMin;
  let skillScore = 0;
  let need = 0;
  for (const [k, v] of Object.entries(job.skills)) {
    skillScore += p.skills[k] ?? 0;
    need += v ?? 0;
  }
  const skillOk = need === 0 || skillScore / need > 0.55;
  const country = state.world.countries.find((c) => c.id === job.countryId)!;
  const demandBoost = job.demand / 200;
  const chanceP = clamp((eduOk ? 0.35 : 0.08) + (expOk ? 0.25 : 0) + (skillOk ? 0.25 : 0.05) + demandBoost - country.unemployment * 0.01 + p.reputation.professional / 400, 0.04, 0.92);
  log.push(`Interview odds ${Math.round(chanceP * 100)}% (education, experience, skills, demand).`);
  if (!chance(rng.bind(null, state), chanceP)) {
    log.push(`${job.employer} passed.`);
    note(state, `Rejected: ${job.title}`, "warn");
    return;
  }
  if (p.career.job) {
    p.career.history.push({
      title: p.career.job.title,
      employer: p.career.job.employer,
      start: `${p.career.yearsInRole.toFixed(1)}y ago`,
      end: date(state),
      salary: p.career.job.salary,
    });
  }
  p.career.employed = true;
  p.career.job = job;
  p.career.yearsInRole = 0;
  p.career.performance = 55;
  p.reputation.professional += 4;
  timeline(state, `Hired as ${job.title} at ${job.employer}.`, "career");
  unlock(state, "first_job");
  log.push(`You are now ${job.title} · ${formatINR(job.salary)}/yr.`);
}

function quitJob(state: GameState, log: string[]) {
  const p = state.player;
  if (!p.career.job) {
    log.push("No job to quit.");
    return;
  }
  p.career.history.push({ title: p.career.job.title, employer: p.career.job.employer, start: "", end: date(state), salary: p.career.job.salary });
  log.push(`Left ${p.career.job.title}.`);
  p.career.job = null;
  p.career.employed = false;
}

function openAccount(state: GameState, bankId: string, kind: "checking" | "savings" | "business", log: string[]) {
  const bank = state.world.banks.find((b) => b.id === bankId);
  if (!bank) {
    log.push("Bank not found.");
    return;
  }
  state.player.finances.accounts.push({
    id: uid("acct"),
    bankId: bank.id,
    bankName: bank.name,
    countryId: bank.countryId,
    type: kind,
    currency: state.world.countries.find((c) => c.id === bank.countryId)!.currency.code,
    balance: 0,
    interestRate: kind === "savings" ? bank.savingsRate : 0.2,
    fee: kind === "checking" ? 150 : 0,
    transactions: [],
  });
  log.push(`Opened ${kind} at ${bank.name}.`);
}

function deposit(state: GameState, accountId: string, amount: number, log: string[]) {
  const acct = state.player.finances.accounts.find((a) => a.id === accountId);
  if (!acct || amount <= 0) return;
  if (state.player.finances.cash < amount) {
    log.push("Not enough cash.");
    return;
  }
  state.player.finances.cash -= amount;
  acct.balance += amount;
  acct.transactions.unshift({ id: uid("tx"), date: date(state), desc: "Deposit", amount, bal: acct.balance, cat: "transfer" });
  log.push(`Deposited ${formatINR(amount)}.`);
}

function withdraw(state: GameState, accountId: string, amount: number, log: string[]) {
  const acct = state.player.finances.accounts.find((a) => a.id === accountId);
  if (!acct || amount <= 0) return;
  if (acct.balance < amount) {
    log.push("Insufficient funds.");
    return;
  }
  acct.balance -= amount;
  state.player.finances.cash += amount;
  acct.transactions.unshift({ id: uid("tx"), date: date(state), desc: "Withdrawal", amount: -amount, bal: acct.balance, cat: "transfer" });
  log.push(`Withdrew ${formatINR(amount)}.`);
}

function transfer(state: GameState, fromId: string, toId: string, amount: number, log: string[]) {
  const a = state.player.finances.accounts.find((x) => x.id === fromId);
  const b = state.player.finances.accounts.find((x) => x.id === toId);
  if (!a || !b || a.balance < amount) {
    log.push("Transfer failed.");
    return;
  }
  a.balance -= amount;
  b.balance += amount;
  log.push("Transferred.");
}

function applyLoan(state: GameState, kind: GameState["player"]["finances"]["loans"][number]["kind"], amount: number, termMonths: number, log: string[]) {
  const p = state.player;
  const country = state.world.countries.find((c) => c.id === p.countryId)!;
  const bank = state.world.banks.find((b) => b.countryId === p.countryId)!;
  const income = Math.max(p.finances.monthlyIncome, (p.career.job?.salary ?? 0) / 12);
  const util = totalUpcoming(p) / Math.max(1, income);
  const score = p.finances.creditScore;
  let rate = bank.lendingRate + (kind === "business" ? 1.5 : kind === "personal" ? 3 : kind === "startup" ? 4 : 0);
  if (score < 580) rate += 6;
  else if (score < 660) rate += 2.5;
  else if (score > 760) rate -= 1.2;
  const maxAmt = income * 12 * (score > 700 ? 6 : 3) + p.properties.reduce((s, x) => s + x.value * 0.4, 0);
  const eligible = amount <= maxAmt && score > 500 && p.finances.defaults < 3 && util < 0.65;
  const prob = clamp(0.15 + (score - 500) / 500 + (eligible ? 0.3 : -0.4) - util, 0.02, 0.9);
  log.push(`Underwrite: score ${score}, rate ~${rate.toFixed(1)}%, p(approve) ${Math.round(prob * 100)}%.`);
  if (!chance(rng.bind(null, state), prob)) {
    log.push("Loan declined.");
    note(state, "A bank declined your application.", "warn");
    history(state, "finance", `Loan declined (${kind})`);
    return;
  }
  const monthly = monthlyLoanPayment(amount, rate, termMonths);
  p.finances.loans.push({
    id: uid("ln"),
    kind,
    lender: bank.name,
    principal: amount,
    remaining: amount,
    rate,
    termMonths,
    monthsLeft: termMonths,
    monthly,
    status: "current",
    missed: 0,
  });
  credit(p, amount, `${kind} loan proceeds`, "loan", date(state));
  log.push(`Approved. ${formatINR(amount)} at ${rate.toFixed(1)}% · ${formatINR(monthly)}/mo.`);
  note(state, "Loan funded.", "good");
}

function totalUpcoming(p: GameState["player"]) {
  return p.finances.loans.filter((l) => l.status !== "paid").reduce((s, l) => s + l.monthly, 0);
}

function repayLoan(state: GameState, loanId: string, amount: number, log: string[]) {
  const loan = state.player.finances.loans.find((l) => l.id === loanId);
  if (!loan) return;
  if (!spend(state.player, amount, "Loan extra pay", "loan", date(state))) {
    log.push("Not enough cash.");
    return;
  }
  loan.remaining = Math.max(0, loan.remaining - amount);
  if (loan.remaining === 0) loan.status = "paid";
  state.player.finances.creditScore = clamp(state.player.finances.creditScore + 2, 300, 900);
  log.push(`Remaining ${formatINR(loan.remaining)}.`);
}

function tradeStock(state: GameState, ticker: string, shares: number, side: "buy" | "sell", log: string[]) {
  const co = state.world.companies.find((c) => c.ticker === ticker);
  if (!co || shares <= 0) {
    log.push("No such listing.");
    return;
  }
  const cost = shares * co.price;
  if (side === "buy") {
    if (!spend(state.player, cost, `Buy ${ticker}`, "inv", date(state))) {
      log.push("Need more cash.");
      return;
    }
    const h = state.player.holdings.find((x) => x.ticker === ticker);
    if (h) {
      h.avgCost = (h.avgCost * h.shares + cost) / (h.shares + shares);
      h.shares += shares;
    } else state.player.holdings.push({ ticker, shares, avgCost: co.price });
    log.push(`Bought ${shares} ${ticker} @ ${formatINR(co.price)}.`);
  } else {
    const h = state.player.holdings.find((x) => x.ticker === ticker);
    if (!h || h.shares < shares) {
      log.push("Not enough shares.");
      return;
    }
    h.shares -= shares;
    credit(state.player, cost, `Sell ${ticker}`, "inv", date(state));
    if (h.shares === 0) state.player.holdings = state.player.holdings.filter((x) => x.ticker !== ticker);
    log.push(`Sold ${shares} ${ticker}.`);
  }
}

function buyBond(state: GameState, bondId: string, qty: number, log: string[]) {
  const b = state.world.bonds.find((x) => x.id === bondId);
  if (!b) return;
  const cost = b.price * qty;
  if (!spend(state.player, cost, `Bond ${b.name}`, "inv", date(state))) {
    log.push("Cannot afford.");
    return;
  }
  state.player.bonds.push({ ...b, qty });
  log.push(`Bought ${qty} × ${b.name}.`);
}

function sellBond(state: GameState, bondId: string, qty: number, log: string[]) {
  const h = state.player.bonds.find((x) => x.id === bondId);
  if (!h || h.qty < qty) return;
  credit(state.player, h.price * qty, "Sell bond", "inv", date(state));
  h.qty -= qty;
  state.player.bonds = state.player.bonds.filter((x) => x.qty > 0);
  log.push("Bond sold.");
}

function buyFund(state: GameState, fundId: string, amount: number, log: string[]) {
  const f = state.world.funds.find((x) => x.id === fundId);
  if (!f) return;
  if (!spend(state.player, amount, `Fund ${f.name}`, "inv", date(state))) {
    log.push("Cannot afford.");
    return;
  }
  const units = amount / f.nav;
  const h = state.player.funds.find((x) => x.id === fundId);
  if (h) {
    h.avgCost = (h.avgCost * h.units + amount) / (h.units + units);
    h.units += units;
  } else state.player.funds.push({ id: f.id, name: f.name, kind: f.kind, units, nav: f.nav, avgCost: f.nav });
  log.push(`Invested ${formatINR(amount)} in ${f.name}.`);
}

function sellFund(state: GameState, fundId: string, units: number, log: string[]) {
  const h = state.player.funds.find((x) => x.id === fundId);
  const f = state.world.funds.find((x) => x.id === fundId);
  if (!h || !f || h.units < units) return;
  h.units -= units;
  credit(state.player, units * f.nav, "Sell fund", "inv", date(state));
  log.push("Fund units sold.");
}

function buyProperty(state: GameState, listingId: string, mortgage: boolean, log: string[]) {
  const listing = state.world.properties.find((p) => p.id === listingId);
  if (!listing) {
    log.push("Listing gone.");
    return;
  }
  let price = listing.distressed ? listing.price * 0.82 : listing.price;
  if (mortgage) {
    const down = price * 0.25;
    if (!spend(state.player, down, `Down payment ${listing.name}`, "property", date(state))) {
      log.push("Need 25% down.");
      return;
    }
    const loanAmt = price - down;
    applyLoan(state, "home", loanAmt, 240, log);
  } else if (!spend(state.player, price, `Buy ${listing.name}`, "property", date(state))) {
    log.push("Cannot afford this property.");
    return;
  }
  state.player.properties.push({
    id: listing.id,
    name: listing.name,
    kind: listing.kind,
    countryId: listing.countryId,
    cityId: listing.cityId,
    district: listing.district,
    size: listing.size,
    condition: listing.condition,
    purchasePrice: price,
    value: listing.price,
    rent: listing.kind === "house" || listing.kind === "apartment" ? 0 : listing.rent,
    occupancy: listing.kind === "house" || listing.kind === "apartment" ? 0 : listing.occupancy,
    maintenance: price * 0.004,
    tax: price * 0.0012,
    mortgaged: mortgage,
    yearBought: state.time.year,
  });
  state.world.properties = state.world.properties.filter((p) => p.id !== listingId);
  unlock(state, "first_prop");
  timeline(state, `Bought ${listing.name}.`, "property");
  log.push(`Purchased ${listing.name} for ${formatINR(price)}.`);
}

function sellProperty(state: GameState, propertyId: string, log: string[]) {
  const prop = state.player.properties.find((p) => p.id === propertyId);
  if (!prop) return;
  credit(state.player, prop.value * 0.97, `Sell ${prop.name}`, "property", date(state));
  state.player.properties = state.player.properties.filter((p) => p.id !== propertyId);
  log.push(`Sold ${prop.name} for ${formatINR(prop.value)}.`);
}

function renovate(state: GameState, propertyId: string, spendAmt: number, log: string[]) {
  const prop = state.player.properties.find((p) => p.id === propertyId);
  if (!prop) return;
  if (!spend(state.player, spendAmt, "Renovation", "property", date(state))) {
    log.push("Cannot afford renovation.");
    return;
  }
  prop.condition = clamp(prop.condition + spendAmt / (prop.value * 0.02), 0, 100);
  prop.value *= 1 + Math.min(0.18, spendAmt / prop.value);
  log.push(`Condition now ${prop.condition.toFixed(0)}.`);
}

function setRent(state: GameState, propertyId: string, occupancyBias: number, log: string[]) {
  const prop = state.player.properties.find((p) => p.id === propertyId);
  if (!prop) return;
  prop.rent = Math.max(0, prop.value * (0.003 + occupancyBias / 1000));
  log.push(`Rent set to ${formatINR(prop.rent)}/mo.`);
}

function develop(state: GameState, propertyId: string, log: string[]) {
  const prop = state.player.properties.find((p) => p.id === propertyId);
  if (!prop) return;
  if (prop.kind !== "land" && !prop.development) {
    log.push("Buy land to develop, or convert an existing site.");
  }
  const budget = prop.value * 1.4;
  prop.development = { stage: "building", budget, spent: 0, progress: 0, units: 12, delayRisk: 20 };
  log.push(`Ground broken. Budget ${formatINR(budget)}.`);
  timeline(state, `Began development at ${prop.name}.`, "property");
}

function foundCompany(state: GameState, payload: FoundPayload, log: string[]) {
  const p = state.player;
  if (payload.capital < 10000) {
    log.push("Need at least ₹10,000 capital.");
    return;
  }
  if (!spend(p, payload.capital, `Found ${payload.name}`, "biz", date(state))) {
    log.push("Not enough cash to incorporate.");
    return;
  }
  const shares = 1000000;
  const co: ListedCompany = {
    id: uid("co"),
    name: payload.name,
    ticker: payload.name.replace(/[^A-Za-z]/g, "").slice(0, 4).toUpperCase() + Math.floor(rng(state) * 90),
    industry: payload.industry,
    countryId: payload.countryId || p.countryId,
    cityId: payload.cityId || p.cityId,
    npc: false,
    founderId: p.id,
    public: false,
    foundedYear: state.time.year,
    revenue: 0,
    costs: payload.capital * 0.04,
    profit: -payload.capital * 0.04,
    cash: payload.capital,
    assets: payload.capital,
    debt: 0,
    employees: payload.industry === "ai" ? 3 : 1,
    customers: 0,
    churn: 0.08,
    quality: 35 + p.skills.entrepreneurship * 0.2,
    priceLevel: payload.price || 100,
    marketing: 8,
    rd: payload.ai || payload.industry === "ai" ? 18 : 6,
    marketShare: 0.1,
    valuation: payload.capital * 1.4,
    shares,
    price: (payload.capital * 1.4) / shares,
    prevPrice: 0,
    pe: industryMeta(payload.industry).pe,
    growth: 0,
    dividend: 0,
    sentiment: 48,
    stage: "startup",
    product: payload.product || payload.industry,
    model: payload.model || "b2c",
    shareholders: [{ id: p.id, name: p.name, type: "player", shares }],
    departments: { engineering: 40, sales: 20, ops: 20, finance: 10, hr: 10 },
    ceo: p.name,
    playerCeo: true,
    playerRole: "founder",
    listed: false,
    forSale: false,
    askingPrice: 0,
    distressed: false,
    history: [],
    ai: payload.ai || payload.industry === "ai" ? { compute: 20, modelQuality: 30 + p.skills.ai * 0.4, apiUsage: 0, infraCost: payload.capital * 0.03 } : undefined,
  };
  state.world.companies.push(co);
  p.ownedCompanyIds.push(co.id);
  p.reputation.business += 8;
  unlock(state, "first_biz");
  if (co.industry === "ai") unlock(state, "ai_founder");
  timeline(state, `Founded ${co.name} (${co.industry}).`, "business");
  log.push(`${co.name} is incorporated. You own 100%. Cash in company ${formatINR(co.cash)}.`);
  note(state, `${co.name} is live.`, "good");
}

function manageCompany(state: GameState, companyId: string, patch: { hire?: number; fire?: number; priceLevel?: number; marketing?: number; rd?: number; quality?: number }, log: string[]) {
  const co = state.world.companies.find((c) => c.id === companyId);
  if (!co) return;
  if (patch.hire) {
    co.employees += patch.hire;
    co.cash -= patch.hire * 40000;
    log.push(`Hired ${patch.hire}.`);
  }
  if (patch.fire) {
    co.employees = Math.max(0, co.employees - patch.fire);
    state.player.reputation.business -= 1;
    log.push(`Let go ${patch.fire}.`);
  }
  if (patch.priceLevel != null) co.priceLevel = clamp(patch.priceLevel, 20, 250);
  if (patch.marketing != null) co.marketing = clamp(patch.marketing, 0, 40);
  if (patch.rd != null) co.rd = clamp(patch.rd, 0, 40);
  if (patch.quality != null) co.quality = clamp(patch.quality, 1, 100);
  log.push("Company settings updated.");
}

function raiseFunding(state: GameState, companyId: string, source: string, amount: number, log: string[]) {
  const co = state.world.companies.find((c) => c.id === companyId);
  if (!co) return;
  const p = state.player;
  let equity = 8;
  let prob = 0.3;
  if (source === "friends") {
    equity = 5;
    prob = 0.55;
  }
  if (source === "angel") {
    equity = 12;
    prob = 0.28 + p.skills.negotiation / 400 + co.quality / 400;
  }
  if (source === "vc") {
    equity = 22;
    prob = 0.12 + co.growth / 200 + p.reputation.business / 400;
  }
  if (source === "bank") {
    applyLoan(state, "startup", amount, 60, log);
    return;
  }
  if (source === "crowd") {
    equity = 6;
    prob = 0.4;
  }
  log.push(`${source} odds ${Math.round(prob * 100)}% for ${equity}% of the company.`);
  if (!chance(rng.bind(null, state), prob)) {
    log.push("They passed.");
    note(state, "Fundraising failed this round.", "warn");
    return;
  }
  const give = Math.round((equity / 100) * co.shares);
  co.shares += 0;
  const playerSh = co.shareholders.find((s) => s.type === "player")!;
  playerSh.shares -= give;
  co.shareholders.push({ id: uid("inv"), name: source.toUpperCase() + " syndicate", type: source === "vc" ? "vc" : "angel", shares: give });
  co.cash += amount;
  co.valuation = Math.max(co.valuation, amount / (equity / 100));
  co.stage = "growth";
  unlock(state, "investor");
  timeline(state, `Raised ${formatINR(amount)} from ${source} for ${equity}%.`, "business");
  log.push(`Closed ${formatINR(amount)} for ${equity}%. You now own ${((playerSh.shares / co.shares) * 100).toFixed(1)}%.`);
}

function ipo(state: GameState, companyId: string, log: string[]) {
  const co = state.world.companies.find((c) => c.id === companyId);
  if (!co) return;
  if (co.revenue < 5e6 || co.stage === "idea") {
    log.push("Too early. Exchanges want revenue.");
    return;
  }
  co.public = true;
  co.listed = true;
  co.stage = "public";
  const float = Math.round(co.shares * 0.2);
  co.shares += float;
  co.shareholders.push({ id: "pub", name: "Public", type: "public", shares: float });
  co.price = co.valuation / co.shares;
  co.cash += float * co.price * 0.95;
  unlock(state, "ipo");
  timeline(state, `${co.name} listed as ${co.ticker}.`, "business");
  news(state, `${co.name} prices IPO as ${co.ticker}`, `The book was covered. Founders are suddenly very public.`, "markets", co.countryId, "Liquidity event; scrutiny rises.");
  log.push(`IPO complete. Ticker ${co.ticker}.`);
}

function buyCompany(state: GameState, companyId: string, log: string[]) {
  const co = state.world.companies.find((c) => c.id === companyId);
  if (!co) return;
  const price = co.askingPrice || co.valuation;
  if (!spend(state.player, price, `Acquire ${co.name}`, "biz", date(state))) {
    log.push("Cannot fund the acquisition.");
    return;
  }
  co.npc = false;
  co.shareholders = [{ id: state.player.id, name: state.player.name, type: "player", shares: co.shares }];
  co.playerRole = "owner";
  co.forSale = false;
  state.player.ownedCompanyIds.push(co.id);
  log.push(`You acquired ${co.name}.`);
  timeline(state, `Acquired ${co.name}.`, "business");
}

function sellShares(state: GameState, companyId: string, pct: number, log: string[]) {
  const co = state.world.companies.find((c) => c.id === companyId);
  if (!co) return;
  const sh = co.shareholders.find((s) => s.type === "player");
  if (!sh) return;
  const give = Math.round(sh.shares * (pct / 100));
  sh.shares -= give;
  const proceeds = (give / co.shares) * co.valuation;
  credit(state.player, proceeds, `Sell ${co.name} shares`, "biz", date(state));
  log.push(`Sold ${pct}% for ${formatINR(proceeds)}.`);
}

function appointCeo(state: GameState, companyId: string, self: boolean, log: string[]) {
  const co = state.world.companies.find((c) => c.id === companyId);
  if (!co) return;
  co.playerCeo = self;
  co.ceo = self ? state.player.name : "Professional CEO";
  co.playerRole = self ? "ceo" : "owner";
  if (self) unlock(state, "ceo");
  log.push(self ? "You are CEO." : "You stepped back from the chair.");
}

function applyGrant(state: GameState, grantId: string, companyId: string | undefined, log: string[]) {
  const g = state.world.grants.find((x) => x.id === grantId);
  if (!g || !g.open) {
    log.push("Programme closed.");
    return;
  }
  const p = state.player;
  let ok = true;
  if (g.kind === "youth" && p.age > 30) ok = false;
  if ((g.kind === "startup" || g.kind === "ai" || g.kind === "innovation") && !p.ownedCompanyIds.length) ok = false;
  if (g.kind === "ai") {
    const co = state.world.companies.find((c) => c.id === (companyId || p.ownedCompanyIds[0]));
    if (!co || (co.industry !== "ai" && !co.ai)) ok = false;
  }
  const skillBoost = (p.skills.writing + p.skills.entrepreneurship) / 400;
  const prob = clamp((ok ? g.prob : g.prob * 0.15) + skillBoost - g.competition / 400, 0.02, 0.75);
  log.push(`Application filed. Modelled odds ${Math.round(prob * 100)}%. Not guaranteed.`);
  const roll = rng(state);
  if (roll > prob + 0.12 && roll < prob + 0.22) {
    log.push("Waitlisted.");
    note(state, `${g.name}: waitlisted.`, "warn");
    return;
  }
  if (roll > prob) {
    log.push("Rejected.");
    note(state, `${g.name} was not awarded.`, "warn");
    history(state, "grant", `Rejected: ${g.name}`);
    return;
  }
  const co = companyId ? state.world.companies.find((c) => c.id === companyId) : null;
  if (co) co.cash += g.amount;
  else credit(p, g.amount, g.name, "grant", date(state));
  g.open = false;
  unlock(state, "grant");
  timeline(state, `Won ${g.name} (${formatINR(g.amount)}).`, "business");
  news(state, `${p.name} awarded ${g.name}`, "A competitive public programme selected a new cohort. Reporting obligations apply.", "grants", g.countryId, "Non-dilutive capital, with milestones.");
  log.push(`Approved: ${formatINR(g.amount)}.`);
}

function pursueOpportunity(state: GameState, opportunityId: string, log: string[]) {
  const op = state.world.opportunities.find((o) => o.id === opportunityId);
  if (!op) {
    log.push("Expired.");
    return;
  }
  if (op.kind === "grant") applyGrant(state, String(op.payload.grantId), undefined, log);
  else if (op.kind === "job") applyJob(state, String(op.payload.jobId), log);
  else if (op.kind === "property" || op.kind === "distressed") buyProperty(state, String(op.payload.listingId), false, log);
  else if (op.kind === "business") buyCompany(state, String(op.payload.companyId), log);
  else if (op.kind === "investor" && state.player.ownedCompanyIds[0]) raiseFunding(state, state.player.ownedCompanyIds[0]!, "angel", 2500000, log);
  else if (op.kind === "incubator" && state.player.ownedCompanyIds[0]) {
    const co = state.world.companies.find((c) => c.id === state.player.ownedCompanyIds[0]);
    if (co && chance(rng.bind(null, state), 0.4)) {
      co.cash += 400000;
      const sh = co.shareholders.find((s) => s.type === "player")!;
      sh.shares *= 0.94;
      log.push("Incubator accepted you. ₹4 lakh in, 6% out.");
    } else log.push("Cohort was full.");
  } else if (op.kind === "contract" && state.player.ownedCompanyIds[0]) {
    const co = state.world.companies.find((c) => c.id === state.player.ownedCompanyIds[0])!;
    co.revenue += 600000;
    state.player.contracts.push({ id: uid("ct"), counterparty: "Government", kind: "gov", value: 18000000, monthsLeft: 24, penalty: 2000000, performance: 50 });
    log.push("Contract signed.");
  }
  state.world.opportunities = state.world.opportunities.filter((o) => o.id !== opportunityId);
}

function travel(state: GameState, countryId: string, cityId: string, intent: string, log: string[]) {
  const country = state.world.countries.find((c) => c.id === countryId);
  const city = state.world.cities.find((c) => c.id === cityId);
  if (!country || !city) return;
  const cost = 25000 + (intent === "move" ? 80000 : 0);
  if (!spend(state.player, cost, `Travel to ${city.name}`, "travel", date(state))) {
    log.push("Cannot afford travel.");
    return;
  }
  state.player.countryId = countryId;
  state.player.cityId = cityId;
  if (intent === "move") state.player.visa = state.player.citizenship.includes(countryId) ? "citizen" : "resident";
  else if (intent === "work") state.player.visa = "work";
  else if (intent === "study") state.player.visa = "student";
  else state.player.visa = "tourist";
  log.push(`Now in ${city.name}, ${country.name} (${state.player.visa}).`);
  timeline(state, `Travelled to ${city.name}, ${country.name}.`, "life");
}

function applyResidency(state: GameState, log: string[]) {
  const p = state.player;
  if (p.citizenship.includes(p.countryId)) {
    log.push("You are already a citizen here.");
    return;
  }
  const country = state.world.countries.find((c) => c.id === p.countryId)!;
  const prob = clamp(0.25 + p.career.experience / 40 + computeNetWorth(state) / 1e8 - country.policy.immigration / 400, 0.05, 0.8);
  if (chance(rng.bind(null, state), prob)) {
    p.visa = "resident";
    p.residency = p.countryId;
    log.push("Residency granted.");
  } else log.push("Residency refused this year.");
}

function applyCitizenship(state: GameState, log: string[]) {
  const p = state.player;
  if (p.citizenship.includes(p.countryId)) {
    log.push("Already a citizen.");
    return;
  }
  if (p.visa !== "resident" && p.visa !== "work") {
    log.push("Usually need residency first.");
    return;
  }
  const prob = 0.2 + p.reputation.personal / 300;
  if (chance(rng.bind(null, state), prob)) {
    p.citizenship.push(p.countryId);
    p.visa = "citizen";
    unlock(state, "citizen");
    timeline(state, `Gained citizenship of ${p.countryId}.`, "life");
    log.push("Citizenship granted.");
  } else log.push("Not this cycle.");
}

function joinParty(state: GameState, partyId: string, log: string[]) {
  const party = state.world.parties.find((p) => p.id === partyId);
  if (!party) return;
  state.player.politics.partyId = party.id;
  state.player.politics.partyName = party.name;
  state.player.politics.role = state.player.politics.role === "none" ? "member" : state.player.politics.role;
  state.player.politics.countryId = party.countryId;
  state.player.politics.platform = { ...party.platform };
  log.push(`Joined ${party.name}.`);
  timeline(state, `Joined ${party.name}.`, "politics");
}

function createParty(state: GameState, name: string, platform: PolicyVector, log: string[]) {
  const id = uid("pty");
  state.world.parties.push({
    id,
    countryId: state.player.countryId,
    name,
    color: "#f5d78e",
    leader: state.player.name,
    seats: 0,
    popularity: 4 + state.player.skills.politics * 0.05,
    funds: state.player.politics.campaignCash,
    members: 120,
    platform,
    playerCreated: true,
  });
  state.player.politics.partyId = id;
  state.player.politics.partyName = name;
  state.player.politics.role = "party_leader";
  state.player.politics.platform = platform;
  state.player.politics.countryId = state.player.countryId;
  unlock(state, "party");
  timeline(state, `Founded political party ${name}.`, "politics");
  log.push(`${name} is registered.`);
}

function campaign(state: GameState, spendAmt: number, log: string[]) {
  if (!spend(state.player, spendAmt, "Campaign", "politics", date(state))) {
    log.push("Need cash to campaign.");
    return;
  }
  state.player.politics.campaignCash += spendAmt * 0.2;
  state.player.politics.popularity = clamp(state.player.politics.popularity + spendAmt / 200000 + state.player.skills.speaking * 0.02, 0, 95);
  log.push(`Popularity ${state.player.politics.popularity.toFixed(1)}.`);
}

function runForOffice(state: GameState, office: string, log: string[]) {
  const p = state.player;
  if (p.age < 21) {
    log.push("Too young to stand.");
    return;
  }
  if (!p.politics.partyId) {
    log.push("Join or found a party first.");
    return;
  }
  const ladder = ["local_candidate", "local_office", "regional", "representative", "minister", "party_leader", "head"] as const;
  const idx = Math.max(0, ladder.indexOf(p.politics.role as (typeof ladder)[number]));
  p.politics.role = ladder[Math.min(idx + 1, ladder.length - 1)]!;
  p.politics.office = office;
  const country = state.world.countries.find((c) => c.id === p.countryId)!;
  const oppPop = 30 + rng(state) * 40;
  const you = p.politics.popularity + p.politics.campaignCash / 5e5 + p.skills.speaking * 0.15 + p.reputation.media * 0.1;
  const won = you + normal(rng.bind(null, state), 0, 8) > oppPop;
  p.politics.elections.push({
    year: state.time.year,
    office,
    result: won ? "won" : "lost",
    voteShare: won ? 51 + rng(state) * 10 : 35 + rng(state) * 14,
    turnout: 60,
  });
  if (won) {
    unlock(state, "elected");
    if (p.politics.role === "head") {
      country.headOfGov = p.name;
      country.rulingPartyId = p.politics.partyId!;
      unlock(state, "head");
    }
    timeline(state, `Elected ${office}.`, "politics");
    log.push(`Won ${office}.`);
  } else {
    log.push(`Lost ${office}. Competitors ran a real race.`);
    note(state, "Election lost — the other campaign was better funded or better liked.", "warn");
  }
}

function setPolicy(state: GameState, policy: Partial<PolicyVector>, log: string[]) {
  if (state.player.politics.role !== "head" && state.player.politics.role !== "minister") {
    log.push("You do not control the budget.");
    return;
  }
  state.player.politics.platform = { ...state.player.politics.platform, ...policy };
  const country = state.world.countries.find((c) => c.id === state.player.countryId)!;
  country.policy = { ...country.policy, ...policy };
  if (policy.tax != null) {
    country.corpTax = 10 + policy.tax * 0.3;
    country.incomeTax = 10 + policy.tax * 0.4;
  }
  log.push("Policy updated. The economy will respond over coming months.");
  news(state, `${country.name} shifts policy`, "Cabinet published a new mix of tax, spending and industrial priorities.", "politics", country.id, "Firms, markets and voters will reprice.");
}

function proposeBill(state: GameState, topic: string, magnitude: number, log: string[]) {
  if (state.player.politics.role === "none" || state.player.politics.role === "volunteer") {
    log.push("Need office to propose bills.");
    return;
  }
  const meta = BILL_TOPICS.find((b) => b.id === topic) ?? BILL_TOPICS[0]!;
  const yes = 40 + state.player.politics.popularity * 0.3 + (rng(state) - 0.5) * 20;
  const passed = yes > 50;
  state.player.politics.billsProposed += 1;
  if (passed) {
    const country = state.world.countries.find((c) => c.id === state.player.countryId)!;
    const key = meta.key;
    country.policy[key] = clamp(country.policy[key] + magnitude, 0, 100);
    log.push(`Bill passed: ${meta.label}.`);
    news(state, `Law passed: ${meta.label}`, `The chamber divided ${Math.round(yes)}–${Math.round(100 - yes)}.`, "politics", country.id, "Legal change will feed into the economy.");
  } else log.push(`Bill failed in the chamber (${Math.round(yes)}% yes).`);
}

function conVote(state: GameState, resolutionId: string, vote: "yes" | "no" | "abstain", log: string[]) {
  const res = state.world.con.resolutions.find((r) => r.id === resolutionId);
  if (!res) return;
  if (vote === "yes") res.yes += 1;
  if (vote === "no") res.no += 1;
  if (vote === "abstain") res.abstain += 1;
  if (res.yes + res.no + res.abstain > 12) {
    res.status = res.yes > res.no ? "passed" : "failed";
  }
  unlock(state, "con");
  log.push(`Voted ${vote} on ${res.title}.`);
}

function conPropose(state: GameState, title: string, log: string[]) {
  if (state.player.influence.international < 15 && state.player.politics.role !== "head") {
    log.push("Need more international standing.");
    return;
  }
  state.world.con.resolutions.unshift({ id: uid("res"), title, status: "proposed", yes: 0, no: 0, abstain: 0 });
  unlock(state, "con");
  log.push("Resolution submitted to the Concord.");
}

function socialPost(state: GameState, platform: string, topic: string, spendAmt: number, log: string[]) {
  if (spendAmt) spend(state.player, spendAmt, "Boosted post", "social", date(state));
  const acc = state.player.social.platforms.find((p) => p.platform === platform) ?? state.player.social.platforms[0]!;
  const virality = rng(state) * (10 + state.player.skills.writing * 0.2 + spendAmt / 5000);
  acc.posts += 1;
  acc.followers = Math.round(acc.followers + virality * 12);
  acc.engagement = clamp(acc.engagement * 0.8 + virality, 0, 100);
  state.player.reputation.social += virality > 8 ? 2 : 0.3;
  log.push(`Post on ${acc.platform} (${topic}). +${Math.round(virality * 12)} followers.`);
  if (virality > 12) {
    news(state, `${state.player.name} goes briefly viral`, "A post punched above its weight. Brands noticed. So did critics.", "social", state.player.countryId, "Followers and scrutiny both rise.");
  }
}

function foundMedia(state: GameState, kind: string, name: string, log: string[]) {
  if (!spend(state.player, 250000, `Found ${name}`, "media", date(state))) {
    log.push("Need ₹2.5 lakh to launch.");
    return;
  }
  state.player.media.outlets.push(name + " · " + kind);
  state.player.reputation.media += 8;
  if (state.player.media.outlets.length >= 2) unlock(state, "media");
  timeline(state, `Launched ${kind} ${name}.`, "media");
  log.push(`${name} is publishing.`);
}

function crimeAct(state: GameState, kind: string, intensity: number, log: string[]) {
  const p = state.player;
  const payout = (8000 + intensity * 12000) * (0.5 + rng(state));
  const heat = 6 + intensity * 8;
  const caught = chance(rng.bind(null, state), clamp(0.05 + p.crime.heat / 200 + intensity * 0.04, 0.04, 0.6));
  log.push(`Risk modelled at ${Math.round(clamp(0.05 + p.crime.heat / 200 + intensity * 0.04, 0.04, 0.6) * 100)}%. Fictional mechanic only.`);
  if (caught) {
    p.crime.heat += heat * 1.5;
    p.crime.evidence += 12;
    p.crime.arrests += 1;
    p.reputation.criminal += 6;
    p.reputation.personal -= 8;
    note(state, "You were implicated. Legal process begins.", "bad");
    history(state, "crime", `Caught during ${kind}`);
    log.push("The attempt failed and drew police attention.");
    return;
  }
  credit(p, payout, `Underground · ${kind}`, "crime", date(state));
  p.crime.path = true;
  p.crime.heat += heat;
  p.crime.moneyFromCrime += payout;
  p.reputation.criminal += 2;
  log.push(`Gained ${formatINR(payout)}. Heat ${p.crime.heat.toFixed(0)}.`);
}

function foundOrg(state: GameState, kind: GameState["player"]["orgs"][number]["kind"], name: string, doctrine: string, log: string[]) {
  state.player.orgs.push({
    id: uid("org"),
    kind,
    name,
    doctrine,
    members: 8,
    loyalty: 70,
    reputation: 20,
    funds: 0,
    scrutiny: kind === "criminal" ? 20 : 5,
    influence: 4,
    facilities: 0,
  });
  if (kind === "criminal") state.player.crime.organizationId = state.player.orgs[state.player.orgs.length - 1]!.id;
  log.push(`${name} founded.`);
}

function orgAct(state: GameState, orgId: string, act: string, log: string[]) {
  const org = state.player.orgs.find((o) => o.id === orgId);
  if (!org) return;
  if (act === "recruit") {
    org.members += 3 + Math.floor(rng(state) * 6);
    org.loyalty -= 1;
  }
  if (act === "media") org.reputation += 3;
  if (act === "facility") {
    if (spend(state.player, 120000, "Facility", "org", date(state))) org.facilities += 1;
  }
  if (act === "donate") {
    const d = 20000;
    if (spend(state.player, d, "Donation", "org", date(state))) org.funds += d;
  }
  log.push(`${org.name} updated.`);
}

function factorialRatio(n: number, k: number): number {
  let p = 1;
  for (let i = 0; i < k; i++) p *= (n - i);
  return p;
}

function minesMultiplier(safePicked: number, tiles: number, mines: number, house = 0.03): number {
  if (safePicked <= 0) return 1;
  const safe = tiles - mines;
  let p = 1;
  for (let i = 0; i < safePicked; i++) p *= (safe - i) / (tiles - i);
  return (1 - house) / Math.max(1e-9, p);
}

function gamble(state: GameState, game: string, stake: number, extra: Record<string, unknown>, log: string[]) {
  if (stake <= 0) return;
  if (!spend(state.player, stake, `Wager ${game}`, "gamble", date(state))) {
    log.push("Stake exceeds bankroll.");
    return;
  }
  const p = state.player;
  p.gambling.lifetimeWagered += stake;
  p.gambling.bankrollSessions += 1;
  p.gambling.lastGame = game;
  let win = 0;
  let detail = "";
  if (game === "roulette") {
    const n = Math.floor(rng(state) * 37);
    const pickN = Number(extra.number ?? -1);
    const color = extra.color as string | undefined;
    const red = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
    if (pickN >= 0 && pickN === n) win = stake * 36;
    else if (color === "red" && red.includes(n)) win = stake * 2;
    else if (color === "black" && n !== 0 && !red.includes(n)) win = stake * 2;
    detail = `Ball ${n}. P(single)=1/37 ≈ 2.70%, fair 36:1, house edge 2.70%.`;
  } else if (game === "dice") {
    const d = 1 + Math.floor(rng(state) * 6);
    if (d >= Number(extra.over ?? 4)) win = stake * 2.1;
    detail = `Rolled ${d}. P(≥5) on d6 = 33.3%.`;
  } else if (game === "cards") {
    const playerC = 16 + Math.floor(rng(state) * 6);
    const dealer = 16 + Math.floor(rng(state) * 6);
    if (playerC > dealer) win = stake * 1.9;
    detail = `You ${playerC} vs ${dealer}. Approx P(win) ~47% after house rules.`;
  } else if (game === "slots") {
    const sp = rng(state);
    if (sp > 0.97) win = stake * 12;
    else if (sp > 0.85) win = stake * 2;
    detail = "Three-reel fiction. RTP ~92%.";
  } else if (game === "lottery") {
    const hit = chance(rng.bind(null, state), 1 / 5000);
    if (hit) win = stake * 2500;
    detail = "P(jackpot) = 1/5000. EV << stake.";
  } else if (game === "mines") {
    const tiles = 25;
    const mines = Number(extra.mines ?? 5);
    const picks = Number(extra.picks ?? 3);
    let hit = false;
    let safe = 0;
    for (let i = 0; i < picks; i++) {
      const remain = tiles - i;
      const mLeft = mines - (hit ? 1 : 0);
      if (rng(state) < mLeft / remain) {
        hit = true;
        break;
      }
      safe++;
    }
    const multi = minesMultiplier(safe, tiles, mines);
    if (!hit) win = stake * multi;
    detail = `5×5, ${mines} mines, ${picks} picks. Survived ${safe}. Multiplier if cashout after ${safe}: ${multi.toFixed(2)}×. P(survive k) = Π (safe-i)/(tiles-i).`;
  }
  if (win > 0) {
    credit(p, win, `Payout ${game}`, "gamble", date(state));
    p.gambling.lifetimeWon += win;
    log.push(`Won ${formatINR(win)}. ${detail}`);
  } else {
    p.gambling.lifetimeLost += stake;
    log.push(`Lost ${formatINR(stake)}. ${detail}`);
  }
  void factorialRatio;
}

function foundCasino(state: GameState, name: string, cityId: string, log: string[]) {
  if (!spend(state.player, 8e6, "Casino build", "biz", date(state))) {
    log.push("Need ₹80 lakh+ to open a house.");
    return;
  }
  state.world.casinos.push({
    id: uid("cas"),
    name,
    cityId,
    countryId: state.player.countryId,
    games: ["roulette", "dice", "cards", "slots", "mines"],
    staff: 40,
    security: 50,
    marketing: 20,
    volume: 0,
    revenue: 0,
    costs: 200000,
    regulation: 40,
  });
  unlock(state, "casino_tycoon");
  log.push(`${name} licensed (fictional).`);
}

function foundBank(state: GameState, name: string, log: string[]) {
  const capital = 2e7;
  if (!spend(state.player, capital, "Bank capital", "biz", date(state))) {
    log.push("Regulators want ₹2 crore capital.");
    return;
  }
  state.world.banks.push({
    id: uid("bank"),
    name,
    countryId: state.player.countryId,
    deposits: capital * 3,
    loans: capital * 2,
    capital,
    npl: 1,
    savingsRate: 3,
    lendingRate: 9,
    playerOwned: true,
    branches: 1,
    profit: 0,
  });
  unlock(state, "banker");
  timeline(state, `Founded ${name} bank.`, "business");
  log.push("Bank chartered.");
}

function foundInsurer(state: GameState, name: string, log: string[]) {
  if (!spend(state.player, 1e7, "Insurer capital", "biz", date(state))) {
    log.push("Need ₹1 crore reserves.");
    return;
  }
  state.world.insurers.push({
    id: uid("ins"),
    name,
    countryId: state.player.countryId,
    premiums: 0,
    claims: 0,
    reserves: 1e7,
    playerOwned: true,
  });
  log.push("Insurer licensed.");
}

function buyInsurance(state: GameState, kind: "life" | "property" | "health", log: string[]) {
  state.player.insurance[kind] = true;
  state.player.insurance.premium += kind === "life" ? 1800 : 1200;
  log.push(`${kind} cover on.`);
}

function haveChild(state: GameState, log: string[]) {
  if (state.player.age < 18) {
    log.push("Not yet.");
    return;
  }
  const child = {
    id: uid("fam"),
    name: `${pick(rng.bind(null, state), ["Ayaan", "Ira", "Noor", "Leo", "Zara", "Dev"])} ${state.player.name.split(" ").slice(-1)[0]}`,
    relation: "child" as const,
    age: 0,
    alive: true,
    wealth: 0,
    countryId: state.player.countryId,
  };
  state.player.family.members.push(child);
  if (!state.player.family.willHeirId) state.player.family.willHeirId = child.id;
  timeline(state, `${child.name} was born.`, "family");
  log.push(`${child.name} joins the family.`);
}

function continueAsHeir(state: GameState, log: string[]) {
  const heir = state.player.family.members.find((m) => m.id === state.player.family.willHeirId) ?? state.player.family.members.find((m) => m.relation === "child");
  if (!heir) {
    log.push("No heir.");
    return;
  }
  const old = state.player.name;
  state.player.name = heir.name;
  state.player.age = Math.max(18, heir.age);
  state.player.alive = true;
  state.player.health = 80;
  state.player.causeOfDeath = null;
  state.player.family.generation += 1;
  state.successorUsed = true;
  unlock(state, "dynasty");
  timeline(state, `${heir.name} inherits the estate of ${old}.`, "family");
  log.push(`You now play ${heir.name}, generation ${state.player.family.generation}.`);
}

function interview(state: GameState, tone: string, log: string[]) {
  if (tone === "open") {
    state.player.reputation.media += 4;
    state.player.reputation.personal += 2;
  } else if (tone === "deny") {
    state.player.reputation.media -= 2;
    state.player.crime.heat += 1;
  } else {
    state.player.reputation.media += 1;
  }
  log.push("Statement issued.");
}

function network(state: GameState, log: string[]) {
  state.player.network.push({
    id: uid("npc"),
    name: `${pick(rng.bind(null, state), ["Asha", "Julian", "Sera", "Wei"])} ${pick(rng.bind(null, state), ["Tan", "Voss", "Rao"])}`,
    role: pick(rng.bind(null, state), ["investor", "journalist", "official", "founder"]),
    closeness: 20,
  });
  state.player.energy -= 4;
  log.push("You expanded the Rolodex.");
}

function createFund(state: GameState, name: string, kind: GameState["world"]["funds"][number]["kind"], log: string[]) {
  if (!spend(state.player, 5e6, "Seed fund", "inv", date(state))) {
    log.push("Need ₹50 lakh to seed a fund.");
    return;
  }
  state.world.funds.push({ id: uid("fund"), name, kind, nav: 100, prev: 100, holdings: state.world.companies.slice(0, 12).map((c) => c.ticker), expense: 0.8 });
  log.push(`${name} launched.`);
}

function resolveDecision(state: GameState, decisionId: string, optionId: string, log: string[]) {
  const d = state.pending.find((x) => x.id === decisionId);
  if (!d) return;
  state.pending = state.pending.filter((x) => x.id !== decisionId);
  if (d.kind === "investor") {
    const co = state.world.companies.find((c) => c.id === d.context.companyId);
    if (!co) return;
    let equity = Number(d.context.equity);
    let amount = Number(d.context.amount);
    if (optionId === "reject") {
      log.push("You passed on the round.");
      return;
    }
    if (optionId === "other") {
      log.push("You keep shopping the round.");
      return;
    }
    if (optionId === "negotiate") {
      const ok = chance(rng.bind(null, state), 0.35 + state.player.skills.negotiation / 200);
      if (ok) equity = Math.max(6, equity - 4);
      else amount *= 0.85;
      log.push(ok ? "Better terms." : "They tightened.");
    }
    const give = Math.round((equity / 100) * co.shares);
    const sh = co.shareholders.find((s) => s.type === "player");
    if (sh) sh.shares -= give;
    co.shareholders.push({ id: uid("inv"), name: "Angel syndicate", type: "angel", shares: give });
    co.cash += amount;
    co.valuation = Math.max(co.valuation, amount / (equity / 100));
    unlock(state, "investor");
    log.push(`Took ${formatINR(amount)} for ${equity}%.`);
  } else if (d.kind === "promotion" && optionId === "take" && state.player.career.job) {
    state.player.career.job.salary *= 1.18;
    state.player.career.job.rank += 1;
    state.player.career.job.hours += 4;
    log.push("Promoted.");
  } else if (d.kind === "layoff") {
    if (optionId === "package" && state.player.career.job) {
      credit(state.player, state.player.career.job.salary / 4, "Severance", "salary", date(state));
      quitJob(state, log);
    } else if (chance(rng.bind(null, state), 0.4)) log.push("You kept the seat — for now.");
    else {
      quitJob(state, log);
      log.push("You were cut anyway.");
    }
  } else if (d.kind === "press") {
    interview(state, optionId === "open" ? "open" : optionId === "deny" ? "deny" : "spin", log);
  } else if (d.kind === "scandal") {
    if (optionId === "ignore") {
      state.player.politics.popularity -= 6;
      state.world.countries.find((c) => c.id === state.player.countryId)!.approval -= 3;
    } else if (optionId === "investigate") {
      state.player.politics.popularity -= 1;
      state.player.reputation.political += 2;
    } else {
      state.player.politics.popularity += 1;
    }
    log.push("Handled.");
  } else if (d.kind === "arrest") {
    if (optionId === "lawyer") {
      spend(state.player, 150000, "Counsel", "legal", date(state));
      if (chance(rng.bind(null, state), 0.55)) {
        log.push("Charges dropped.");
        state.player.crime.heat *= 0.5;
      } else {
        state.player.crime.convictions += 1;
        log.push("Fined. Record stained.");
        spend(state.player, 80000, "Fine", "legal", date(state));
      }
    } else {
      state.player.crime.heat *= 0.7;
      state.player.reputation.personal -= 4;
      log.push("You cooperated. Heat down, reputation down.");
    }
  } else if (d.kind === "death") {
    if (optionId === "heir") continueAsHeir(state, log);
    else log.push("This dynasty ends here.");
  }
}

export { minesMultiplier };
void INDUSTRIES;
void liquidCash;
void round;
