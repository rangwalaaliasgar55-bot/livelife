import { actOnSave, deleteSave, loadSave } from "@/lib/persist";
import type { PlayerAction } from "@/lib/sim/types";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const state = await loadSave(id);
  if (!state) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json({ state });
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = (await req.json()) as { action: PlayerAction };
  if (!body?.action?.type) {
    return Response.json({ error: "Action required" }, { status: 400 });
  }
  const result = await actOnSave(id, body.action);
  if ("status" in result && result.status === 404) {
    return Response.json({ error: result.error }, { status: 404 });
  }
  return Response.json(result);
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  await deleteSave(id);
  return Response.json({ ok: true });
}
