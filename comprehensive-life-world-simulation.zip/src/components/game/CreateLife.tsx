"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { COUNTRY_DEFS, MODES } from "@/lib/sim/catalog";
import type { GameMode, Personality } from "@/lib/sim/types";
import { formatINR } from "@/lib/sim/util";
import { Btn, Card, Field, Input, Label, Select } from "./ui";

const SKINS = ["#f6d7c3", "#e0ac69", "#c68642", "#8d5524", "#5c3317"];
const HAIRS = ["#1a120b", "#3b2219", "#6b3a2a", "#2c2c2c", "#d1b184"];
const PORTRAITS = ["gold", "teal", "rose", "violet", "slate"];

export function CreateLife() {
  const router = useRouter();
  const [name, setName] = useState("Asha Menon");
  const [mode, setMode] = useState<GameMode>("normal");
  const [countryId, setCountryId] = useState("indara");
  const [age, setAge] = useState(18);
  const [skin, setSkin] = useState(SKINS[2]!);
  const [hair, setHair] = useState(HAIRS[0]!);
  const [portrait, setPortrait] = useState("gold");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [traits, setTraits] = useState<Personality>({
    risk: 48,
    ambition: 62,
    discipline: 55,
    negotiation: 44,
    leadership: 40,
    creativity: 52,
    patience: 50,
    frugality: 46,
  });

  const modeDef = useMemo(() => MODES.find((m) => m.id === mode)!, [mode]);

  async function start() {
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch("/api/game", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: `${name} · ${modeDef.name}`,
          input: {
            mode,
            name,
            age: mode === "random" ? age : modeDef.age,
            countryId,
            background: "middle",
            educationLevel: modeDef.edu,
            wealth: modeDef.wealth,
            traits,
            appearance: { skin, hair, eyes: "#3d2914", style: "sharp", portrait },
            nationality: COUNTRY_DEFS.find((c) => c.id === countryId)?.adjective,
          },
        }),
      });
      const data = await res.json();
      if (!data.id) throw new Error(data.error || "Could not create life");
      router.push(`/play/${data.id}`);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
      setBusy(false);
    }
  }

  return (
    <Card className="mt-8">
      <Label>Begin a life</Label>
      <h2 className="font-serif text-3xl">Character & sandbox</h2>
      <div className="mt-5 grid gap-6 lg:grid-cols-2">
        <div className="space-y-4">
          <Field label="Name">
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Starting country">
            <Select value={countryId} onChange={(e) => setCountryId(e.target.value)}>
              {COUNTRY_DEFS.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} · {c.currency.symbol}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Age override (random mode uses this)">
            <Input type="number" min={16} max={70} value={age} onChange={(e) => setAge(Number(e.target.value))} />
          </Field>
          <div>
            <p className="tick">Appearance</p>
            <div className="mt-2 flex gap-2">
              {SKINS.map((s) => (
                <button key={s} onClick={() => setSkin(s)} className="h-7 w-7 rounded-full border" style={{ background: s, outline: skin === s ? "2px solid #e4c37a" : undefined }} />
              ))}
            </div>
            <div className="mt-2 flex gap-2">
              {HAIRS.map((s) => (
                <button key={s} onClick={() => setHair(s)} className="h-7 w-7 rounded-full border" style={{ background: s, outline: hair === s ? "2px solid #e4c37a" : undefined }} />
              ))}
            </div>
            <div className="mt-2 flex gap-2">
              {PORTRAITS.map((s) => (
                <button key={s} onClick={() => setPortrait(s)} className="rounded-full border border-white/10 px-3 py-1 text-xs">
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div>
          <p className="tick">Mode</p>
          <div className="mt-2 grid grid-cols-2 gap-2">
            {MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                className={`rounded-2xl border p-3 text-left text-sm ${mode === m.id ? "border-amber-200/50 bg-amber-200/10" : "border-white/10"}`}
              >
                <div className="font-medium">{m.name}</div>
                <div className="text-[11px] text-[var(--muted)]">{m.blurb}</div>
                <div className="mt-1 text-[11px] text-amber-200/80">{formatINR(m.wealth)} · age {m.age}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
      <div className="mt-6 grid gap-3 md:grid-cols-4">
        {(Object.keys(traits) as (keyof Personality)[]).map((k) => (
          <label key={k} className="text-xs text-[var(--muted)]">
            {k} · {traits[k]}
            <input
              className="mt-1 w-full"
              type="range"
              min={10}
              max={90}
              value={traits[k]}
              onChange={(e) => setTraits({ ...traits, [k]: Number(e.target.value) })}
            />
          </label>
        ))}
      </div>
      {err ? <p className="mt-3 text-sm text-rose-300">{err}</p> : null}
      <div className="mt-6">
        <Btn disabled={busy} onClick={() => void start()}>
          {busy ? "Seeding the world…" : "Enter the simulation"}
        </Btn>
      </div>
    </Card>
  );
}
