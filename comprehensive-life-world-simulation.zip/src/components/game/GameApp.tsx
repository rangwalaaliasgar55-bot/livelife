"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { GameState, PlayerAction } from "@/lib/sim/types";
import { businessEquity, computeNetWorth, liquidCash, portfolioValue, propertyValue, totalDebt } from "@/lib/sim/finance";
import { formatDate, formatINR, formatPct, monthName } from "@/lib/sim/util";
import { Avatar, Btn, Card, Label, Modal, Spark, Stat } from "./ui";
import { Panels } from "./panels";

const NAV: { id: string; label: string; group: string }[] = [
  { id: "dashboard", label: "Control", group: "You" },
  { id: "life", label: "Life", group: "You" },
  { id: "career", label: "Career & Skills", group: "You" },
  { id: "bank", label: "Banking", group: "Capital" },
  { id: "markets", label: "Markets", group: "Capital" },
  { id: "property", label: "Property", group: "Capital" },
  { id: "business", label: "Companies", group: "Capital" },
  { id: "opps", label: "Opportunities", group: "Capital" },
  { id: "world", label: "World Map", group: "World" },
  { id: "politics", label: "Politics", group: "World" },
  { id: "concord", label: "Concord", group: "World" },
  { id: "media", label: "Media & Pulse", group: "World" },
  { id: "under", label: "Underground", group: "World" },
  { id: "news", label: "Newsroom", group: "Record" },
  { id: "legacy", label: "Legacy", group: "Record" },
];

export function GameApp({ id }: { id: string }) {
  const [state, setState] = useState<GameState | null>(null);
  const [view, setView] = useState("dashboard");
  const [log, setLog] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await fetch(`/api/game/${id}`, { cache: "no-store" });
    const data = await res.json();
    if (data.state) setState(data.state);
    else setErr(data.error || "Could not load life");
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  const act = useCallback(
    async (action: PlayerAction) => {
      setBusy(true);
      setErr(null);
      try {
        const res = await fetch(`/api/game/${id}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action }),
        });
        const data = await res.json();
        if (data.state) setState(data.state);
        setLog(data.log ?? []);
        if (data.error) setErr(data.error);
      } catch (e) {
        setErr(e instanceof Error ? e.message : "Network error");
      } finally {
        setBusy(false);
      }
    },
    [id],
  );

  const nw = useMemo(() => (state ? computeNetWorth(state) : 0), [state]);

  if (!state) {
    return (
      <main className="grid min-h-screen place-items-center">
        <p className="tick">{err || "Opening the world…"}</p>
      </main>
    );
  }

  const p = state.player;
  const country = state.world.countries.find((c) => c.id === p.countryId)!;
  const city = state.world.cities.find((c) => c.id === p.cityId);
  const idx = state.world.indexHistory;
  const pending = state.pending[0];

  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 flex h-screen w-60 shrink-0 flex-col border-r border-[var(--line)] bg-[#0a0c12]/90 p-4">
        <a href="/" className="font-serif text-2xl gold-text">
          AURELION
        </a>
        <p className="tick mt-1">World simulation</p>
        <nav className="mt-6 flex-1 space-y-4 overflow-auto pr-1">
          {["You", "Capital", "World", "Record"].map((g) => (
            <div key={g}>
              <p className="tick mb-2">{g}</p>
              <div className="space-y-1">
                {NAV.filter((n) => n.group === g).map((n) => (
                  <button
                    key={n.id}
                    onClick={() => setView(n.id)}
                    className={`block w-full rounded-xl px-3 py-1.5 text-left text-sm ${view === n.id ? "bg-white/10 text-amber-200" : "text-[var(--muted)] hover:bg-white/5"}`}
                  >
                    {n.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </nav>
        <div className="mt-3 text-xs text-[var(--muted)]">
          Auto-saved · {state.lastSave ? new Date(state.lastSave).toLocaleTimeString() : "—"}
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex flex-wrap items-center gap-4 border-b border-[var(--line)] bg-[#0a0c12]/80 px-6 py-3">
          <Avatar appearance={p.appearance} name={p.name} />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-baseline gap-3">
              <h1 className="font-serif text-2xl">{p.name}</h1>
              <span className="text-sm text-[var(--muted)]">
                {p.age} · {city?.name}, {country.name}
              </span>
            </div>
            <p className="text-xs text-[var(--muted)]">
              {formatDate(state.time.year, state.time.month)} · {p.career.job?.title ?? (p.ownedCompanyIds.length ? "Founder" : "Unaffiliated")} ·{" "}
              {p.alive ? "Living" : "Deceased"}
            </p>
          </div>
          <div className="text-right">
            <p className="tick">Net worth</p>
            <p className="font-serif text-xl gold-text">{formatINR(nw)}</p>
          </div>
          <div className="flex gap-2">
            <Btn disabled={busy || !!pending || !p.alive} onClick={() => void act({ type: "tick", months: 1 })}>
              Live 1 month
            </Btn>
            <Btn kind="ghost" disabled={busy || !!pending || !p.alive} onClick={() => void act({ type: "tick", months: 12 })}>
              Live 1 year
            </Btn>
          </div>
        </header>

        <div className="grid grid-cols-2 gap-3 px-6 py-4 md:grid-cols-4 xl:grid-cols-8">
          <Stat label="Cash" value={formatINR(liquidCash(p))} />
          <Stat label="Portfolio" value={formatINR(portfolioValue(state))} />
          <Stat label="Property" value={formatINR(propertyValue(p))} />
          <Stat label="Business eq." value={formatINR(businessEquity(state))} />
          <Stat label="Debt" value={formatINR(totalDebt(p))} tone="bad" />
          <Stat label={`${country.currency.code} policy rate`} value={`${country.interestRate.toFixed(2)}%`} sub={`CPI ${country.inflation.toFixed(1)}%`} />
          <Stat label="Growth" value={formatPct(country.gdpGrowth)} tone={country.gdpGrowth >= 0 ? "good" : "bad"} />
          <Stat label="Followers" value={p.social.followers.toLocaleString()} />
        </div>

        {log.length ? (
          <div className="mx-6 mb-3 rounded-2xl border border-amber-200/20 bg-amber-200/5 px-4 py-2 text-sm">
            {log.map((l, i) => (
              <p key={i} className="m-0">
                {l}
              </p>
            ))}
          </div>
        ) : null}
        {err ? <p className="px-6 text-sm text-rose-300">{err}</p> : null}

        <main className="flex-1 px-6 pb-16">
          {view === "dashboard" ? (
            <Dashboard state={state} act={act} setView={setView} />
          ) : (
            <Panels view={view} state={state} act={act} busy={busy} />
          )}
        </main>
      </div>

      {pending ? (
        <Modal title={pending.title}>
          <p className="text-sm leading-6 text-[var(--muted)]">{pending.body}</p>
          <p className="tick mt-3">
            {monthName(pending.month)} {pending.year}
          </p>
          <div className="mt-5 flex flex-col gap-2">
            {pending.options.map((o) => (
              <button
                key={o.id}
                disabled={busy}
                onClick={() => void act({ type: "resolve", decisionId: pending.id, optionId: o.id })}
                className="rounded-2xl border border-[var(--line)] px-4 py-3 text-left hover:bg-white/5"
              >
                <div className="font-medium">{o.label}</div>
                {o.hint ? <div className="text-xs text-[var(--muted)]">{o.hint}</div> : null}
              </button>
            ))}
          </div>
        </Modal>
      ) : null}

      {busy ? (
        <div className="pointer-events-none fixed bottom-4 right-4 rounded-full bg-black/60 px-4 py-2 text-xs text-amber-200">
          Simulating…
        </div>
      ) : null}

      {idx.length > 2 ? (
        <div className="pointer-events-none fixed bottom-0 left-60 right-0 h-10 opacity-30">
          <Spark values={idx.slice(-48).map((x) => x.v)} />
        </div>
      ) : null}
    </div>
  );
}

function Dashboard({
  state,
  act,
  setView,
}: {
  state: GameState;
  act: (a: PlayerAction) => void;
  setView: (v: string) => void;
}) {
  const p = state.player;
  const country = state.world.countries.find((c) => c.id === p.countryId)!;
  const nwHist = p.finances.netWorthHistory.map((x) => x.v);
  const firms = state.world.companies.filter((c) => c.shareholders.some((s) => s.type === "player"));
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card className="lg:col-span-2">
        <Label>Life</Label>
        <div className="mt-3 grid gap-4 md:grid-cols-2">
          <div>
            <p className="font-serif text-3xl">{p.name}</p>
            <p className="mt-1 text-sm text-[var(--muted)]">
              Age {p.age} · Health {Math.round(p.health)} · Stress {Math.round(p.stress)}
            </p>
            <p className="mt-3 text-sm leading-6">
              {p.career.job
                ? `${p.career.job.title} at ${p.career.job.employer} (${formatINR(p.career.job.salary)}/yr).`
                : "No employer. The labour market is still hiring — or you could found something."}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Btn kind="ghost" onClick={() => setView("career")}>
                Work
              </Btn>
              <Btn kind="ghost" onClick={() => setView("opps")}>
                Opportunities
              </Btn>
              <Btn kind="ghost" onClick={() => void act({ type: "rest" })}>
                Rest
              </Btn>
              <Btn kind="ghost" onClick={() => void act({ type: "network" })}>
                Network
              </Btn>
            </div>
          </div>
          <div>
            <Label>Net worth history</Label>
            <Spark values={nwHist.length ? nwHist : [0, 0]} />
            <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
              <div>
                Income this month
                <div className="text-teal-300">{formatINR(p.finances.monthlyIncome)}</div>
              </div>
              <div>
                Expenses
                <div className="text-rose-300">{formatINR(p.finances.monthlyExpenses)}</div>
              </div>
            </div>
          </div>
        </div>
      </Card>
      <Card>
        <Label>World now · {country.name}</Label>
        <p className="mt-2 font-serif text-xl">{country.headOfGov}</p>
        <p className="text-xs text-[var(--muted)]">Head of government</p>
        <div className="mt-4 space-y-1 text-sm">
          <div className="flex justify-between">
            <span>GDP growth</span>
            <span>{formatPct(country.gdpGrowth)}</span>
          </div>
          <div className="flex justify-between">
            <span>Inflation</span>
            <span>{country.inflation.toFixed(1)}%</span>
          </div>
          <div className="flex justify-between">
            <span>Unemployment</span>
            <span>{country.unemployment.toFixed(1)}%</span>
          </div>
          <div className="flex justify-between">
            <span>Approval</span>
            <span>{country.approval.toFixed(0)}</span>
          </div>
          <div className="flex justify-between">
            <span>AI adoption</span>
            <span>{country.aiAdoption.toFixed(0)}</span>
          </div>
        </div>
        <Btn kind="ghost" onClick={() => setView("world")}>
          Open map
        </Btn>
      </Card>
      <Card className="lg:col-span-2">
        <Label>Wire</Label>
        <ul className="mt-3 space-y-3">
          {state.news.slice(0, 5).map((n) => (
            <li key={n.id}>
              <p className="text-sm font-medium">{n.headline}</p>
              <p className="text-xs text-[var(--muted)]">
                {n.tag} · {n.impact}
              </p>
            </li>
          ))}
        </ul>
      </Card>
      <Card>
        <Label>Firms you touch</Label>
        {firms.length === 0 ? (
          <p className="mt-3 text-sm text-[var(--muted)]">None yet. Found one from Companies.</p>
        ) : (
          firms.map((f) => (
            <div key={f.id} className="mt-3 border-t border-white/5 pt-3 text-sm">
              <div className="font-medium">{f.name}</div>
              <div className="text-[var(--muted)]">
                {f.industry} · {f.stage} · {formatINR(f.revenue)} rev
              </div>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}
